//1. Реализовать свой тип коллекции «очередь» (queue) c использованием дженериков.
//
//2. Добавить ему несколько методов высшего порядка, полезных для этой коллекции (пример: filter для массивов)
//
//3. * Добавить свой subscript, который будет возвращать nil в случае обращения к несуществующему индексу.

import UIKit
import Foundation


protocol Years {
    var year: Int { get }
}

class Year: Years, CustomStringConvertible {
    var year: Int {
        return year1 * year2
    }
    

    var year1: Int
    var year2: Int
    
    init(a: Int, b: Int) {
        self.year1 = a
        self.year2 = b
        
    }
    var description: String {
        return "\(year1), \(year2)"
    }
}

struct Queue<T: Years >: CustomStringConvertible {
    private var elements: [T] = []
    
    mutating func enqeue(_ element: T) {
        elements.append(element)
    }
    mutating func dequeue() -> T? {
        return elements.removeLast()
    }
    var description: String {
        return ("\(elements)")
    }
    
    var years: Int {
        var year = 0
        for element in elements {
            year += element.year
        }
        return year
    }
    
    subscript(indexes: Int ...) -> Int {
        var year = 0
        
        for i in indexes where i < elements.count {
            year += elements[i].year
        }
        return year
    }
    
    subscript(index: Int) -> T? {
        get {
            guard index > elements.count else { return nil }
            return elements[index]
        }
        set {
            guard index < elements.count, let val = newValue else { return }
            elements[index] = val
        }
    }
}

func filter(array: [Int], predicate:(Int) -> Bool) -> [Int] {
    var tmpYearsArray = [Int]()
    for element in array {
        if predicate(element) {
            tmpYearsArray.append(element)
        }
    }
    return tmpYearsArray
}

var queue = Queue<Year>()
queue.enqeue(Year(a: 2020, b: 2030))
queue.enqeue(Year(a: 2017, b: 2018))
queue.enqeue(Year(a: 2027, b: 2005))
queue.enqeue(Year(a: 2004, b: 2007))

queue.dequeue()



var array = [2000, 2001, 2002, 2003, 2004, 2005]
array.sort{ $0 > $1 }
print(array)
array.forEach {
    print($0)
}
print(queue.years)
queue[1] = Year(a: 2020, b: 2021)
print(queue.years)


